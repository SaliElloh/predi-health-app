class Patient {
  String ? picture, name, id;
  Patient({this.id, this.name, this.picture});
}